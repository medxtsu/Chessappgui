import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'chess_utils.dart';
import 'engine.dart';
import 'explainer.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ChessApp());
}

class ChessApp extends StatelessWidget {
  const ChessApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Chess GUI',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
            useMaterial3: true,
            colorSchemeSeed: Colors.teal,
            brightness: Brightness.dark),
        builder: (c, w) =>
            Directionality(textDirection: TextDirection.rtl, child: w!),
        home: const Home(),
      );
}

// ───────────────────────── البروفايل ─────────────────────────

class BotProfile {
  String name;
  int elo;
  String avatar; // 'emoji:🤖' أو مسار صورة

  BotProfile(this.name, this.elo, this.avatar);

  static Future<BotProfile> load() async {
    final p = await SharedPreferences.getInstance();
    return BotProfile(p.getString('name') ?? 'بوت', p.getInt('elo') ?? 1500,
        p.getString('avatar') ?? 'emoji:🤖');
  }

  Future<void> save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('name', name);
    await p.setInt('elo', elo);
    await p.setString('avatar', avatar);
  }
}

class Avatar extends StatelessWidget {
  final String avatar;
  final double radius;
  const Avatar(this.avatar, {this.radius = 24, super.key});

  @override
  Widget build(BuildContext context) {
    if (avatar.startsWith('emoji:')) {
      return CircleAvatar(
          radius: radius,
          child: Text(avatar.substring(6), style: TextStyle(fontSize: radius)));
    }
    return CircleAvatar(
        radius: radius, backgroundImage: FileImage(File(avatar)));
  }
}

Color classColor(MoveClass c) => switch (c) {
      MoveClass.best => Colors.green.shade700,
      MoveClass.excellent => Colors.green.shade500,
      MoveClass.good => Colors.lightGreen.shade700,
      MoveClass.inaccuracy => Colors.amber.shade800,
      MoveClass.mistake => Colors.orange.shade800,
      MoveClass.blunder => Colors.red.shade700,
    };

// ───────────────────────── الشاشة الرئيسية ─────────────────────────

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int tab = 0;
  BotProfile? profile;
  late final Future<void> ready;
  List<Ply> game = [];
  bool userWhite = true;

  @override
  void initState() {
    super.initState();
    ready = Engine.instance.init();
    BotProfile.load().then((p) => setState(() => profile = p));
  }

  @override
  Widget build(BuildContext context) {
    final p = profile;
    if (p == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    return Scaffold(
      body: SafeArea(
        child: IndexedStack(index: tab, children: [
          PlayPage(
            profile: p,
            ready: ready,
            onGameEnd: (plies, white) => setState(() {
              game = plies;
              userWhite = white;
            }),
            onReview: () => setState(() => tab = 1),
          ),
          ReviewPage(key: ObjectKey(game), plies: game, userWhite: userWhite),
          BotPage(profile: p, onChanged: () => setState(() {})),
        ]),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.sports_esports), label: 'لعب'),
          NavigationDestination(icon: Icon(Icons.analytics), label: 'مراجعة'),
          NavigationDestination(icon: Icon(Icons.smart_toy), label: 'البوت'),
        ],
      ),
    );
  }
}

// ───────────────────────── الرقعة ─────────────────────────

class BoardView extends StatelessWidget {
  final String fen;
  final bool flipped;
  final String? selected, lastFrom, lastTo;
  final List<String> targets;
  final void Function(String)? onTap;

  const BoardView({
    super.key,
    required this.fen,
    this.flipped = false,
    this.selected,
    this.targets = const [],
    this.lastFrom,
    this.lastTo,
    this.onTap,
  });

  static const _glyph = {
    'k': '♚',
    'q': '♛',
    'r': '♜',
    'b': '♝',
    'n': '♞',
    'p': '♟\uFE0E',
  };

  @override
  Widget build(BuildContext context) {
    final board = parseBoard(fen);
    // الرقعة دايماً LTR حتى لا تنعكس في الواجهة العربية
    return Directionality(
      textDirection: TextDirection.ltr,
      child: AspectRatio(
        aspectRatio: 1,
        child: Column(children: [
          for (var r = 0; r < 8; r++)
            Expanded(
              child: Row(children: [
                for (var c = 0; c < 8; c++) Expanded(child: _cell(board, c, r)),
              ]),
            ),
        ]),
      ),
    );
  }

  Widget _cell(List<List<String>> board, int col, int row) {
    final file = flipped ? 7 - col : col;
    final rank = flipped ? row + 1 : 8 - row;
    final sq = '${String.fromCharCode(97 + file)}$rank';
    final p = board[8 - rank][file];
    final dark = (file + rank) % 2 == 1;
    var color = dark ? const Color(0xFF769656) : const Color(0xFFEEEED2);
    if (sq == lastFrom || sq == lastTo) {
      color = Color.alphaBlend(const Color(0x66FFEB3B), color);
    }
    if (sq == selected) {
      color = Color.alphaBlend(const Color(0x99FFC107), color);
    }
    final isWhite = p.isNotEmpty && p == p.toUpperCase();
    return GestureDetector(
      onTap: onTap == null ? null : () => onTap!(sq),
      child: Container(
        color: color,
        child: Stack(alignment: Alignment.center, children: [
          if (p.isNotEmpty)
            Padding(
              padding: const EdgeInsets.all(2),
              child: FittedBox(
                child: Text(
                  _glyph[p.toLowerCase()]!,
                  style: TextStyle(
                    fontSize: 100,
                    height: 1.1,
                    color: isWhite ? Colors.white : Colors.black,
                    shadows: isWhite
                        ? const [
                            Shadow(color: Colors.black, blurRadius: 3),
                            Shadow(color: Colors.black, offset: Offset(0.8, 0.8)),
                          ]
                        : null,
                  ),
                ),
              ),
            ),
          if (targets.contains(sq))
            Container(
              width: 10,
              height: 10,
              decoration: const BoxDecoration(
                  color: Color(0x88000000), shape: BoxShape.circle),
            ),
        ]),
      ),
    );
  }
}

// ───────────────────────── اللعب ضد البوت ─────────────────────────

class PlayPage extends StatefulWidget {
  final BotProfile profile;
  final Future<void> ready;
  final void Function(List<Ply>, bool) onGameEnd;
  final VoidCallback onReview;
  const PlayPage({
    super.key,
    required this.profile,
    required this.ready,
    required this.onGameEnd,
    required this.onReview,
  });

  @override
  State<PlayPage> createState() => _PlayPageState();
}

class _PlayPageState extends State<PlayPage> {
  String fen = startFen;
  final plies = <Ply>[];
  bool userWhite = true;
  String? selected;
  List<String> targets = [];
  bool thinking = false;
  String? result;
  int gameId = 0;

  bool get _userTurn => fen.split(' ')[1] == (userWhite ? 'w' : 'b');

  Future<void> _newGame(bool white) async {
    gameId++;
    setState(() {
      fen = startFen;
      plies.clear();
      userWhite = white;
      selected = null;
      targets = [];
      result = null;
      thinking = false;
    });
    if (!white) await _botMove();
  }

  void _tap(String sq) {
    if (thinking || result != null || !_userTurn) return;
    if (selected != null && targets.contains(sq)) {
      _play(selected!, sq);
      return;
    }
    final piece = pieceAt(parseBoard(fen), sq);
    final mine = piece != null && (piece == piece.toUpperCase()) == userWhite;
    setState(() {
      selected = mine ? sq : null;
      targets = mine ? legalTargets(fen, sq) : [];
    });
  }

  Future<void> _play(String from, String to) async {
    final piece = pieceAt(parseBoard(fen), from)!;
    final promo = piece.toLowerCase() == 'p' && (to.endsWith('8') || to.endsWith('1'))
        ? 'q'
        : '';
    await _applyMove('$from$to$promo');
    if (result == null) await _botMove();
  }

  Future<void> _applyMove(String uci) async {
    final after = applyUci(fen, uci);
    if (after == null) return;
    final san = sanFor(fen, uci) ?? uci;
    setState(() {
      plies.add(Ply(fen, after, uci, san));
      fen = after;
      selected = null;
      targets = [];
    });
    final st = statusOf(after);
    if (st.over) {
      final whiteToMove = after.split(' ')[1] == 'w';
      setState(() => result = st.mate
          ? (whiteToMove ? 'كش مات — فاز الأسود' : 'كش مات — فاز الأبيض')
          : 'تعادل');
      widget.onGameEnd(List.of(plies), userWhite);
    }
  }

  Future<void> _botMove() async {
    final id = gameId;
    setState(() => thinking = true);
    await widget.ready;
    final uci = await Engine.instance.botMove(fen, widget.profile.elo);
    if (!mounted || id != gameId) return;
    setState(() => thinking = false);
    if (uci.length >= 4 && uci != '(none)') await _applyMove(uci);
  }

  void _resign() {
    setState(() => result = 'استسلمت');
    widget.onGameEnd(List.of(plies), userWhite);
  }

  @override
  Widget build(BuildContext context) {
    final bot = widget.profile;
    final last = plies.isEmpty ? null : plies.last.uci;
    return ListView(padding: const EdgeInsets.all(12), children: [
      Row(children: [
        Avatar(bot.avatar, radius: 22),
        const SizedBox(width: 10),
        Expanded(
          child: Text('${bot.name} (${bot.elo})',
              style: Theme.of(context).textTheme.titleMedium),
        ),
        if (thinking)
          const SizedBox(
              width: 18,
              height: 18,
              child: CircularProgressIndicator(strokeWidth: 2)),
      ]),
      const SizedBox(height: 10),
      BoardView(
        fen: fen,
        flipped: !userWhite,
        selected: selected,
        targets: targets,
        lastFrom: last?.substring(0, 2),
        lastTo: last?.substring(2, 4),
        onTap: _tap,
      ),
      const SizedBox(height: 10),
      if (result != null)
        Center(
          child: Text(result!, style: Theme.of(context).textTheme.titleLarge),
        ),
      const SizedBox(height: 6),
      Wrap(spacing: 8, runSpacing: 8, alignment: WrapAlignment.center, children: [
        FilledButton(
            onPressed: () => _newGame(true), child: const Text('العب أبيض')),
        FilledButton(
            onPressed: () => _newGame(false), child: const Text('العب أسود')),
        OutlinedButton(
            onPressed: result == null && plies.isNotEmpty ? _resign : null,
            child: const Text('استسلام')),
        OutlinedButton(
          onPressed: plies.isEmpty
              ? null
              : () {
                  widget.onGameEnd(List.of(plies), userWhite);
                  widget.onReview();
                },
          child: const Text('مراجعة'),
        ),
      ]),
    ]);
  }
}

// ───────────────────────── مراجعة المباراة ─────────────────────────

class ReviewPage extends StatefulWidget {
  final List<Ply> plies;
  final bool userWhite;
  const ReviewPage({super.key, required this.plies, required this.userWhite});

  @override
  State<ReviewPage> createState() => _ReviewPageState();
}

class _ReviewPageState extends State<ReviewPage> {
  List<MoveReview>? reviews;
  bool analyzing = false;
  int done = 0;
  int idx = -1;

  Future<void> _analyze() async {
    final plies = widget.plies;
    setState(() {
      analyzing = true;
      done = 0;
    });
    final fens = [plies.first.fenBefore, ...plies.map((p) => p.fenAfter)];
    final evals = <EvalResult>[];
    for (final f in fens) {
      evals.add(await Engine.instance.analyze(f)); // 300ms لكل موضع
      if (!mounted) return;
      setState(() => done = evals.length);
    }
    final rv = <MoveReview>[
      for (var i = 0; i < plies.length; i++)
        reviewMove(i, plies[i], evals[i], evals[i + 1]),
    ];
    setState(() {
      reviews = rv;
      analyzing = false;
      idx = rv.length - 1;
    });
  }

  void _go(int i) => setState(() => idx = i.clamp(-1, widget.plies.length - 1));

  @override
  Widget build(BuildContext context) {
    final plies = widget.plies;
    if (plies.isEmpty) {
      return const Center(child: Text('العب مباراة أول ثم ارجع هنا للمراجعة.'));
    }
    final rv = reviews;
    if (rv == null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text('${plies.length} نقلة جاهزة للتحليل'),
            const SizedBox(height: 16),
            if (analyzing) ...[
              LinearProgressIndicator(value: done / (plies.length + 1)),
              const SizedBox(height: 8),
              Text('$done / ${plies.length + 1}'),
            ] else
              FilledButton(onPressed: _analyze, child: const Text('حلّل المباراة')),
          ]),
        ),
      );
    }

    final r = idx >= 0 ? rv[idx] : null;
    final fen = idx < 0 ? plies.first.fenBefore : plies[idx].fenAfter;
    final last = idx < 0 ? null : plies[idx].uci;
    final textTheme = Theme.of(context).textTheme;

    return ListView(padding: const EdgeInsets.all(12), children: [
      BoardView(
        fen: fen,
        flipped: !widget.userWhite,
        lastFrom: last?.substring(0, 2),
        lastTo: last?.substring(2, 4),
      ),
      Directionality(
        textDirection: TextDirection.ltr,
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          IconButton(onPressed: () => _go(-1), icon: const Icon(Icons.first_page)),
          IconButton(onPressed: () => _go(idx - 1), icon: const Icon(Icons.chevron_left)),
          Text('${idx + 1} / ${plies.length}'),
          IconButton(onPressed: () => _go(idx + 1), icon: const Icon(Icons.chevron_right)),
          IconButton(onPressed: () => _go(plies.length - 1), icon: const Icon(Icons.last_page)),
        ]),
      ),
      Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: r == null
              ? const Text('اضغط على نقلة أو استخدم الأسهم.')
              : Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Container(
                      width: 10,
                      height: 10,
                      decoration: BoxDecoration(
                          color: classColor(r.cls), shape: BoxShape.circle),
                    ),
                    const SizedBox(width: 8),
                    Text('${r.san} — ${classLabel(r.cls)}',
                        style: textTheme.titleMedium),
                  ]),
                  const SizedBox(height: 6),
                  Text(r.text),
                ]),
        ),
      ),
      const SizedBox(height: 8),
      Text(
        'دقة الأبيض: ${accuracy(rv, true).round()}%   |   دقة الأسود: ${accuracy(rv, false).round()}%',
        textAlign: TextAlign.center,
      ),
      const SizedBox(height: 8),
      Wrap(spacing: 4, runSpacing: 4, children: [
        for (var i = 0; i < rv.length; i++)
          ActionChip(
            label: Text(
              '${i ~/ 2 + 1}${i.isEven ? '.' : '...'} ${rv[i].san}',
              style: const TextStyle(color: Colors.white),
            ),
            backgroundColor: classColor(rv[i].cls),
            side: i == idx ? const BorderSide(color: Colors.white, width: 2) : null,
            onPressed: () => _go(i),
          ),
      ]),
    ]);
  }
}

// ───────────────────────── إعدادات البوت ─────────────────────────

class BotPage extends StatefulWidget {
  final BotProfile profile;
  final VoidCallback onChanged;
  const BotPage({super.key, required this.profile, required this.onChanged});

  @override
  State<BotPage> createState() => _BotPageState();
}

class _BotPageState extends State<BotPage> {
  late final TextEditingController nameCtl =
      TextEditingController(text: widget.profile.name);

  static const presets = ['🤖', '🧙', '🐲', '👑', '🦊', '🐺', '🧠'];

  void _update(void Function() f) {
    setState(f);
    widget.profile.save();
    widget.onChanged();
  }

  Future<void> _pick() async {
    final x = await ImagePicker()
        .pickImage(source: ImageSource.gallery, maxWidth: 512, imageQuality: 85);
    if (x == null) return;
    final dir = await getApplicationDocumentsDirectory();
    final saved = await File(x.path)
        .copy('${dir.path}/bot_${DateTime.now().millisecondsSinceEpoch}.jpg');
    _update(() => widget.profile.avatar = saved.path);
  }

  @override
  Widget build(BuildContext context) {
    final p = widget.profile;
    return ListView(padding: const EdgeInsets.all(16), children: [
      Center(
        child: GestureDetector(
          onTap: _pick,
          child: Avatar(p.avatar, radius: 56),
        ),
      ),
      const SizedBox(height: 6),
      const Center(child: Text('اضغط على الصورة لاختيار صورة من المعرض')),
      const SizedBox(height: 10),
      Wrap(spacing: 8, alignment: WrapAlignment.center, children: [
        for (final e in presets)
          ActionChip(
            label: Text(e, style: const TextStyle(fontSize: 22)),
            onPressed: () => _update(() => p.avatar = 'emoji:$e'),
          ),
      ]),
      const SizedBox(height: 16),
      TextField(
        controller: nameCtl,
        decoration: const InputDecoration(
            labelText: 'اسم البوت', border: OutlineInputBorder()),
        onChanged: (v) => _update(() => p.name = v.trim().isEmpty ? 'بوت' : v.trim()),
      ),
      const SizedBox(height: 16),
      Text('Elo: ${p.elo}', style: Theme.of(context).textTheme.titleMedium),
      Slider(
        value: p.elo.toDouble(),
        min: 400,
        max: 3190,
        divisions: 279,
        label: '${p.elo}',
        onChanged: (v) => _update(() => p.elo = v.round()),
      ),
      const Text(
        'ملاحظة: Stockfish يدعم Elo من 1320 إلى 3190 رسمياً. '
        'تحت 1320 القوة تقريبية (Skill Level).',
        style: TextStyle(fontSize: 12),
      ),
    ]);
  }
}
