import 'package:flutter/material.dart';
import 'chess_utils.dart';
import 'engine.dart';
import 'dart:io';
import 'settings.dart';
import 'board_view.dart';
import 'timer_widget.dart';

class PlayPage extends StatefulWidget {
  final AppSettings settings;
  final Future<void> engineReady;
  final void Function(List<Ply> plies, bool userWasWhite) onGameEnd;
  final VoidCallback onReview;
  const PlayPage({
    super.key,
    required this.settings,
    required this.engineReady,
    required this.onGameEnd,
    required this.onReview,
  });
  @override State<PlayPage> createState() => _PlayPageState();
}

class _PlayPageState extends State<PlayPage> {
  String _fen = startFen;
  final _plies = <Ply>[];
  bool _userWhite = true;
  String? _selected;
  List<String> _targets = [];
  bool _thinking = false;
  String? _result;
  String? _hintFrom, _hintTo;
  int _gameId = 0;
  ChessClock? _clock;

  AppSettings get _s => widget.settings;
  bool get _userTurn => _fen.split(' ')[1] == (_userWhite ? 'w' : 'b');

  @override
  void initState() {
    super.initState();
    _newGame(true);
  }

  @override
  void dispose() {
    _clock?.dispose();
    super.dispose();
  }

  void _newGame(bool white) {
    _clock?.dispose();
    ChessClock? newClock;
    if (_s.timerEnabled) {
      newClock = ChessClock(
        seconds: _s.timerSeconds,
        incrementMs: _s.timerIncrement ? _s.timerIncrementSec * 1000 : 0,
        whiteTurn: true,
      );
      newClock.onFlag = () => setState(() {
        _result = newClock!.whiteMs <= 0 ? 'نفد وقت الأبيض' : 'نفد وقت الأسود';
      });
    }
    final id = ++_gameId;
    setState(() {
      _fen = startFen;
      _plies.clear();
      _userWhite = white;
      _selected = null;
      _targets = [];
      _result = null;
      _hintFrom = null;
      _hintTo = null;
      _thinking = false;
      _clock = newClock;
    });
    if (!white) _botMove(id);
  }

  // ─── الضغط على خانة ───
  void _tap(String sq) {
    if (_thinking || _result != null || !_userTurn) return;

    // لو اخترنا قطعة ولقينا هدف، العب
    if (_selected != null && _targets.contains(sq)) {
      _doMove(_selected!, sq);
      return;
    }

    // اختيار قطعة
    final piece = pieceAt(parseBoard(_fen), sq);
    final mine = piece != null && (piece == piece.toUpperCase()) == _userWhite;

    setState(() {
      if (mine) {
        _selected = sq;
        _targets = legalTargets(_fen, sq);
      } else {
        _selected = null;
        _targets = [];
      }
      _hintFrom = null;
      _hintTo = null;
    });
  }

  Future<void> _doMove(String from, String to) async {
    if (needsPromo(_fen, from, to)) {
      final promo = await _promoDialog();
      if (promo == null) return;
      await _applyMove('$from$to$promo');
    } else {
      await _applyMove('$from$to');
    }
    if (_result == null) await _botMove(_gameId);
  }

  Future<void> _applyMove(String uci) async {
    final after = applyUci(_fen, uci);
    if (after == null) return;
    final san = sanFor(_fen, uci) ?? uci;
    _clock?.switchTurn();
    if (_clock != null && !_clock!.running && _plies.length >= 1) _clock!.start();
    setState(() {
      _plies.add(Ply(_fen, after, uci, san));
      _fen = after;
      _selected = null;
      _targets = [];
      _hintFrom = null;
      _hintTo = null;
    });
    final st = statusOf(after);
    if (st.over) {
      _clock?.stop();
      final whiteToMove = after.split(' ')[1] == 'w';
      setState(() => _result = st.mate
          ? (whiteToMove ? 'كش مات — فاز الأسود 🏆' : 'كش مات — فاز الأبيض 🏆')
          : 'تعادل');
      widget.onGameEnd(List.of(_plies), _userWhite);
    }
  }

  Future<void> _botMove(int id) async {
    if (!mounted || id != _gameId) return;
    setState(() => _thinking = true);
    await widget.engineReady;
    final uci = await Engine.instance.botMove(_fen, _s.botElo);
    if (!mounted || id != _gameId) return;
    setState(() => _thinking = false);
    if (uci.length >= 4 && uci != '(none)') {
      _clock?.switchTurn();
      await _applyMove(uci);
    }
  }

  Future<void> _getHint() async {
    if (_thinking || _result != null || !_userTurn) return;
    setState(() => _thinking = true);
    await widget.engineReady;
    final ev = await Engine.instance.hint(_fen);
    if (!mounted) return;
    setState(() {
      _thinking = false;
      if (ev.bestMove.length >= 4) {
        _hintFrom = ev.bestMove.substring(0, 2);
        _hintTo = ev.bestMove.substring(2, 4);
      }
    });
  }

  Future<String?> _promoDialog() async {
    return showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('ترقية إلى:'),
        content: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            for (final p in ['q','r','b','n'])
              GestureDetector(
                onTap: () => Navigator.pop(ctx, p),
                child: Container(
                  width: 52, height: 52,
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.teal, width: 2),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: PieceWidget(
                    _userWhite ? p.toUpperCase() : p,
                    settings: _s, size: 52,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bot = _s;
    final lastUci = _plies.isEmpty ? null : _plies.last.uci;
    final clock = _clock;

    return ListView(padding: const EdgeInsets.all(10), children: [
      // ─── رأس: معلومات الخصم ───
      Row(children: [
        AvatarWidget(bot.botAvatar, radius: 22),
        const SizedBox(width: 8),
        Expanded(child: Text('${bot.botName} (${bot.botElo})',
            style: Theme.of(context).textTheme.titleMedium)),
        if (clock != null) ClockWidget(clock: clock, white: !_userWhite),
        if (_thinking)
          const Padding(
            padding: EdgeInsets.only(right: 8),
            child: SizedBox(width: 18, height: 18,
                child: CircularProgressIndicator(strokeWidth: 2)),
          ),
      ]),
      const SizedBox(height: 8),

      // ─── الرقعة ───
      BoardView(
        fen: _fen,
        settings: _s,
        flipped: !_userWhite,
        selected: _selected,
        targets: _targets,
        lastFrom: lastUci?.substring(0, 2),
        lastTo: lastUci?.substring(2, 4),
        hintFrom: _hintFrom,
        hintTo: _hintTo,
        onTap: _tap,
      ),

      const SizedBox(height: 8),
      // ─── ساعة المستخدم ───
      if (clock != null)
        Row(mainAxisAlignment: MainAxisAlignment.end, children: [
          ClockWidget(clock: clock, white: _userWhite),
        ]),

      const SizedBox(height: 6),
      // ─── نتيجة ───
      if (_result != null)
        Center(child: Text(_result!,
            style: Theme.of(context).textTheme.titleLarge)),

      const SizedBox(height: 8),
      // ─── أزرار ───
      Wrap(spacing: 8, runSpacing: 8, alignment: WrapAlignment.center, children: [
        FilledButton(onPressed: () => _newGame(true),  child: const Text('أبيض')),
        FilledButton(onPressed: () => _newGame(false), child: const Text('أسود')),
        OutlinedButton(
          onPressed: (_result == null && _plies.isNotEmpty) ? () {
            setState(() => _result = 'استسلمت');
            _clock?.stop();
            widget.onGameEnd(List.of(_plies), _userWhite);
          } : null,
          child: const Text('استسلام'),
        ),
        OutlinedButton(onPressed: _getHint, child: const Text('💡 تلميح')),
        OutlinedButton(
          onPressed: _plies.isEmpty ? null : () {
            widget.onGameEnd(List.of(_plies), _userWhite);
            widget.onReview();
          },
          child: const Text('مراجعة'),
        ),
      ]),

      // ─── سجل النقلات ───
      const SizedBox(height: 10),
      if (_plies.isNotEmpty)
        _MoveList(plies: _plies),
    ]);
  }
}

// ─────────────────────────────────────────────────────────────────
class _MoveList extends StatelessWidget {
  final List<Ply> plies;
  const _MoveList({required this.plies});
  @override
  Widget build(BuildContext context) {
    final rows = <TableRow>[];
    for (var i = 0; i < plies.length; i += 2) {
      rows.add(TableRow(children: [
        Padding(padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
            child: Text('${i ~/ 2 + 1}.', style: const TextStyle(color: Colors.grey))),
        Padding(padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
            child: Text(plies[i].san, style: const TextStyle(fontWeight: FontWeight.bold))),
        Padding(padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
            child: i + 1 < plies.length
                ? Text(plies[i + 1].san, style: const TextStyle(fontWeight: FontWeight.bold))
                : const SizedBox()),
      ]));
    }
    return Table(
      columnWidths: const {0: FixedColumnWidth(30), 1: FlexColumnWidth(), 2: FlexColumnWidth()},
      children: rows,
    );
  }
}

