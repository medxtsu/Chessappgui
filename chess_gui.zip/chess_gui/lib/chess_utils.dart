import 'package:chess/chess.dart' as cl;

const startFen = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';

/// نقلة واحدة في المباراة.
class Ply {
  final String fenBefore, fenAfter, uci, san;
  const Ply(this.fenBefore, this.fenAfter, this.uci, this.san);
}

class Status {
  final bool over, mate;
  const Status(this.over, this.mate);
}

/// يحول FEN إلى مصفوفة 8x8 (الصف 0 = الرانك 8). الخانة الفاضية ''.
List<List<String>> parseBoard(String fen) {
  final rows = fen.split(' ')[0].split('/');
  final board = <List<String>>[];
  for (final row in rows) {
    final r = <String>[];
    for (final c in row.split('')) {
      final n = int.tryParse(c);
      if (n != null) {
        r.addAll(List.filled(n, ''));
      } else {
        r.add(c);
      }
    }
    board.add(r);
  }
  return board;
}

String? pieceAt(List<List<String>> board, String sq) {
  final file = sq.codeUnitAt(0) - 97;
  final rank = int.parse(sq[1]);
  final p = board[8 - rank][file];
  return p.isEmpty ? null : p;
}

/// يطبق نقلة UCI ويرجع FEN الجديد، أو null لو النقلة غير قانونية.
String? applyUci(String fen, String uci) {
  final g = cl.Chess.fromFEN(fen);
  final move = <String, String>{
    'from': uci.substring(0, 2),
    'to': uci.substring(2, 4),
  };
  if (uci.length > 4) move['promotion'] = uci.substring(4, 5);
  return g.move(move) ? g.fen : null;
}

/// يحول نقلة UCI إلى SAN (مثل Nf3) بمطابقة النتيجة مع قائمة النقلات القانونية.
String? sanFor(String fen, String uci) {
  final target = applyUci(fen, uci);
  if (target == null) return null;
  for (final s in cl.Chess.fromFEN(fen).moves()) {
    final g = cl.Chess.fromFEN(fen);
    if (g.move(s) && g.fen == target) return s.toString();
  }
  return null;
}

/// الخانات القانونية للقطعة في [from].
List<String> legalTargets(String fen, String from) {
  final out = <String>[];
  for (final f in 'abcdefgh'.split('')) {
    for (var r = 1; r <= 8; r++) {
      final to = '$f$r';
      if (to == from) continue;
      final g = cl.Chess.fromFEN(fen);
      if (g.move({'from': from, 'to': to, 'promotion': 'q'})) out.add(to);
    }
  }
  return out;
}

Status statusOf(String fen) {
  final g = cl.Chess.fromFEN(fen);
  return Status(g.game_over, g.in_checkmate);
}
