import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'settings.dart';

class SettingsPage extends StatefulWidget {
  final AppSettings settings;
  final VoidCallback onChanged;
  const SettingsPage({super.key, required this.settings, required this.onChanged});
  @override State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> with SingleTickerProviderStateMixin {
  late final TabController _tab;
  late final TextEditingController _botNameCtl;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 3, vsync: this);
    _botNameCtl = TextEditingController(text: widget.settings.botName);
  }

  @override void dispose() { _tab.dispose(); _botNameCtl.dispose(); super.dispose(); }

  void _upd(void Function() f) {
    setState(f);
    widget.settings.save();
    widget.onChanged();
  }

  // ────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    final s = widget.settings;
    return Scaffold(
      appBar: AppBar(
        title: const Text('الإعدادات'),
        bottom: TabBar(controller: _tab, tabs: const [
          Tab(text: 'الرقعة'),
          Tab(text: 'البوت'),
          Tab(text: 'المؤقت'),
        ]),
      ),
      body: TabBarView(controller: _tab, children: [
        _boardTab(s),
        _botTab(s),
        _timerTab(s),
      ]),
    );
  }

  // ─── تبويب الرقعة والقطع ───────────────────────────────────────
  Widget _boardTab(AppSettings s) => ListView(padding: const EdgeInsets.all(16), children: [
    Text('لون الرقعة', style: Theme.of(context).textTheme.titleMedium),
    const SizedBox(height: 8),
    Wrap(spacing: 10, runSpacing: 10, children: [
      for (var i = 0; i < boardThemes.length; i++)
        GestureDetector(
          onTap: () => _upd(() => s.boardThemeIdx = i),
          child: Container(
            width: 60, height: 60,
            decoration: BoxDecoration(
              border: Border.all(
                  color: s.boardThemeIdx == i ? Colors.teal : Colors.transparent,
                  width: 3),
              borderRadius: BorderRadius.circular(8),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(5),
              child: Column(children: [
                Expanded(child: Row(children: [
                  Expanded(child: Container(color: boardThemes[i].light)),
                  Expanded(child: Container(color: boardThemes[i].dark)),
                ])),
                Expanded(child: Row(children: [
                  Expanded(child: Container(color: boardThemes[i].dark)),
                  Expanded(child: Container(color: boardThemes[i].light)),
                ])),
              ]),
            ),
          ),
        ),
    ]),
    const SizedBox(height: 20),
    Text('مجموعة القطع', style: Theme.of(context).textTheme.titleMedium),
    const SizedBox(height: 8),
    RadioListTile<String>(
      value: 'default',
      groupValue: s.pieceSetId,
      title: const Text('الافتراضية'),
      onChanged: (v) => _upd(() => s.pieceSetId = v!),
    ),
    for (final set in s.customSets)
      RadioListTile<String>(
        value: set.id,
        groupValue: s.pieceSetId,
        title: Text(set.name),
        secondary: IconButton(
          icon: const Icon(Icons.delete, color: Colors.red),
          onPressed: () async {
            await s.deletePieceSet(set.id);
            _upd(() {});
          },
        ),
        onChanged: (v) => _upd(() => s.pieceSetId = v!),
      ),
    const SizedBox(height: 10),
    FilledButton.icon(
      icon: const Icon(Icons.add_photo_alternate),
      label: const Text('استيراد مجموعة قطع جديدة (12 صورة)'),
      onPressed: () async {
        final nameCtl = TextEditingController();
        final name = await showDialog<String>(
          context: context,
          builder: (c) => AlertDialog(
            title: const Text('اسم المجموعة'),
            content: TextField(controller: nameCtl, decoration: const InputDecoration(hintText: 'مثال: قطع خشبية')),
            actions: [
              TextButton(onPressed: () => Navigator.pop(c), child: const Text('إلغاء')),
              FilledButton(onPressed: () => Navigator.pop(c, nameCtl.text.trim()), child: const Text('تالي')),
            ],
          ),
        );
        if (name == null || name.isEmpty) return;
        final set = await AppSettings.importPieceSet(name);
        if (set == null || !mounted) return;
        _upd(() { s.customSets.add(set); s.pieceSetId = set.id; });
      },
    ),
    const SizedBox(height: 6),
    const Text(
      'سيُطلب منك اختيار 12 صورة بالترتيب:\n'
      'ملك أبيض، وزير أبيض، قلعة بيضاء، فيل أبيض، حصان أبيض، بيدق أبيض،\n'
      'ثم نفس الترتيب للأسود.\n'
      'يدعم PNG و JPEG و GIF متحركة.',
      style: TextStyle(fontSize: 12, color: Colors.grey),
    ),
  ]);

  // ─── تبويب البوت ──────────────────────────────────────────────
  Widget _botTab(AppSettings s) => ListView(padding: const EdgeInsets.all(16), children: [
    Center(child: GestureDetector(
      onTap: () async {
        final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 512);
        if (x == null) return;
        final dir = await getApplicationDocumentsDirectory();
        final dest = '${dir.path}/bot_avatar.jpg';
        await File(x.path).copy(dest);
        _upd(() => s.botAvatar = dest);
      },
      child: AvatarWidget(s.botAvatar, radius: 56),
    )),
    const SizedBox(height: 6),
    const Center(child: Text('اضغط لتغيير الصورة', style: TextStyle(color: Colors.grey))),
    const SizedBox(height: 10),
    Wrap(spacing: 8, alignment: WrapAlignment.center, children: [
      for (final e in ['🤖','🧙','🐱','👑','🦊','🧠','🐺','🔥'])
        ActionChip(
          label: Text(e, style: const TextStyle(fontSize: 22)),
          onPressed: () => _upd(() => s.botAvatar = 'emoji:$e'),
        ),
    ]),
    const SizedBox(height: 16),
    TextField(
      controller: _botNameCtl,
      decoration: const InputDecoration(labelText: 'اسم البوت', border: OutlineInputBorder()),
      onChanged: (v) => _upd(() => s.botName = v.trim().isEmpty ? 'بوت' : v.trim()),
    ),
    const SizedBox(height: 16),
    Row(children: [
      const Text('الإيلو:  '),
      Expanded(child: Text('${s.botElo}',
          style: Theme.of(context).textTheme.titleMedium)),
    ]),
    Slider(
      value: s.botElo.toDouble().clamp(1, 3190),
      min: 1, max: 3190, divisions: 3189,
      label: '${s.botElo}',
      onChanged: (v) => _upd(() => s.botElo = v.round()),
    ),
    Text(
      s.botElo < 400
          ? 'مستوى مبتدئ جداً (Skill Level ${((s.botElo - 1) / 39.9).round()})'
          : s.botElo < 1320
              ? 'مستوى تقريبي (أقل من حد Stockfish الرسمي)'
              : 'Elo رسمي Stockfish',
      style: const TextStyle(fontSize: 11, color: Colors.grey),
    ),
    const SizedBox(height: 8),
    // أزرار سريعة
    Wrap(spacing: 6, children: [
      for (final e in [400, 800, 1000, 1200, 1500, 1800, 2000, 2200, 2500, 3000])
        ActionChip(
          label: Text('$e'),
          onPressed: () => _upd(() => s.botElo = e),
        ),
    ]),
  ]);

  // ─── تبويب المؤقت ─────────────────────────────────────────────
  Widget _timerTab(AppSettings s) => ListView(padding: const EdgeInsets.all(16), children: [
    SwitchListTile(
      title: const Text('تفعيل المؤقت'),
      value: s.timerEnabled,
      onChanged: (v) => _upd(() => s.timerEnabled = v),
    ),
    if (s.timerEnabled) ...[
      const SizedBox(height: 10),
      Text('وقت كل لاعب: ${_fmtMin(s.timerSeconds)}',
          style: Theme.of(context).textTheme.titleMedium),
      Slider(
        value: s.timerSeconds.toDouble(),
        min: 30, max: 3600, divisions: 71,
        label: _fmtMin(s.timerSeconds),
        onChanged: (v) => _upd(() => s.timerSeconds = v.round()),
      ),
      Wrap(spacing: 6, children: [
        for (final sec in [60, 180, 300, 600, 900, 1800, 3600])
          ActionChip(label: Text(_fmtMin(sec)), onPressed: () => _upd(() => s.timerSeconds = sec)),
      ]),
      const SizedBox(height: 10),
      SwitchListTile(
        title: const Text('إضافة ثواني بعد كل نقلة'),
        value: s.timerIncrement,
        onChanged: (v) => _upd(() => s.timerIncrement = v),
      ),
      if (s.timerIncrement) ...[
        Text('الإضافة: ${s.timerIncrementSec} ث'),
        Slider(
          value: s.timerIncrementSec.toDouble(),
          min: 1, max: 30, divisions: 29,
          label: '${s.timerIncrementSec}ث',
          onChanged: (v) => _upd(() => s.timerIncrementSec = v.round()),
        ),
      ],
    ],
  ]);

  String _fmtMin(int s) {
    final m = s ~/ 60;
    final sec = s % 60;
    return m > 0 ? (sec > 0 ? '${m}د ${sec}ث' : '${m}د') : '${sec}ث';
  }
}

