import 'dart:async';
import 'package:flutter/material.dart';

class ChessClock {
  int whiteMs, blackMs;
  final int incrementMs;
  bool whiteTurn;
  bool running = false;
  Timer? _timer;
  void Function()? onFlag; // انتهى الوقت

  ChessClock({
    required int seconds,
    this.incrementMs = 0,
    this.whiteTurn = true,
  })  : whiteMs = seconds * 1000,
        blackMs = seconds * 1000;

  void start() {
    if (running) return;
    running = true;
    _timer = Timer.periodic(const Duration(milliseconds: 100), (_) {
      if (whiteTurn) {
        whiteMs -= 100;
        if (whiteMs <= 0) { whiteMs = 0; running = false; _timer?.cancel(); onFlag?.call(); }
      } else {
        blackMs -= 100;
        if (blackMs <= 0) { blackMs = 0; running = false; _timer?.cancel(); onFlag?.call(); }
      }
    });
  }

  void stop() { running = false; _timer?.cancel(); }

  /// استدعَه بعد كل نقلة
  void switchTurn() {
    if (whiteTurn) whiteMs += incrementMs;
    else blackMs += incrementMs;
    whiteTurn = !whiteTurn;
  }

  void dispose() { _timer?.cancel(); }

  String fmt(int ms) {
    final s = ms ~/ 1000;
    final m = s ~/ 60;
    final sec = s % 60;
    return '${m.toString().padLeft(2,'0')}:${sec.toString().padLeft(2,'0')}';
  }
}

class ClockWidget extends StatefulWidget {
  final ChessClock clock;
  final bool white;
  const ClockWidget({super.key, required this.clock, required this.white});
  @override State<ClockWidget> createState() => _ClockWidgetState();
}

class _ClockWidgetState extends State<ClockWidget> {
  Timer? _refresh;
  @override void initState() {
    super.initState();
    _refresh = Timer.periodic(const Duration(milliseconds: 200), (_) { if (mounted) setState(() {}); });
  }
  @override void dispose() { _refresh?.cancel(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final c = widget.clock;
    final ms = widget.white ? c.whiteMs : c.blackMs;
    final active = c.running && (c.whiteTurn == widget.white);
    final low = ms < 10000;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 150),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      decoration: BoxDecoration(
        color: active ? (low ? Colors.red.shade800 : Colors.teal.shade700) : Colors.grey.shade800,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        c.fmt(ms),
        style: TextStyle(
          fontSize: 22, fontWeight: FontWeight.bold,
          color: low && active ? Colors.white : Colors.white,
          fontFeatures: const [FontFeature.tabularFigures()],
        ),
      ),
    );
  }
}
