import 'package:flutter/material.dart';
import 'chess_utils.dart';
import 'explainer.dart';
import 'settings.dart';

class BoardView extends StatelessWidget {
  final String fen;
  final bool flipped;
  final String? selected, lastFrom, lastTo, hintFrom, hintTo;
  final List<String> targets;
  final Map<String, MoveClass> moveColors; // sq → class (للمراجعة)
  final void Function(String sq)? onTap;
  final AppSettings settings;

  const BoardView({
    super.key,
    required this.fen,
    required this.settings,
    this.flipped = false,
    this.selected,
    this.targets = const [],
    this.lastFrom,
    this.lastTo,
    this.hintFrom,
    this.hintTo,
    this.moveColors = const {},
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final board = parseBoard(fen);
    return Directionality(
      textDirection: TextDirection.ltr,
      child: AspectRatio(
        aspectRatio: 1,
        child: Column(children: [
          for (var r = 0; r < 8; r++)
            Expanded(child: Row(children: [
              for (var c = 0; c < 8; c++)
                Expanded(child: _Cell(
                  board: board,
                  col: c, row: r,
                  flipped: flipped,
                  selected: selected,
                  targets: targets,
                  lastFrom: lastFrom, lastTo: lastTo,
                  hintFrom: hintFrom, hintTo: hintTo,
                  moveColors: moveColors,
                  onTap: onTap,
                  settings: settings,
                )),
            ])),
        ]),
      ),
    );
  }
}

class _Cell extends StatelessWidget {
  final List<List<String>> board;
  final int col, row;
  final bool flipped;
  final String? selected, lastFrom, lastTo, hintFrom, hintTo;
  final List<String> targets;
  final Map<String, MoveClass> moveColors;
  final void Function(String)? onTap;
  final AppSettings settings;

  const _Cell({
    required this.board, required this.col, required this.row,
    required this.flipped, required this.selected, required this.targets,
    required this.lastFrom, required this.lastTo,
    required this.hintFrom, required this.hintTo,
    required this.moveColors, required this.onTap, required this.settings,
  });

  static const _classColors = {
    MoveClass.best:       Color(0xCC4CAF50),
    MoveClass.excellent:  Color(0xCC81C784),
    MoveClass.good:       Color(0xCC8BC34A),
    MoveClass.book:       Color(0xCCBCAAA4),
    MoveClass.inaccuracy: Color(0xCCFFB300),
    MoveClass.mistake:    Color(0xCCFF7043),
    MoveClass.missedWin:  Color(0xCCE53935),
    MoveClass.blunder:    Color(0xCCB71C1C),
  };

  @override
  Widget build(BuildContext context) {
    final file = flipped ? 7 - col : col;
    final rank = flipped ? row + 1 : 8 - row;
    final sq = '${String.fromCharCode(97 + file)}$rank';
    final p = board[8 - rank][file];
    final theme = settings.boardTheme;

    var bg = (file + rank) % 2 == 1 ? theme.dark : theme.light;

    // آخر نقلة
    if (sq == lastFrom || sq == lastTo) {
      bg = Color.alphaBlend(theme.highlight, bg);
    }
    // تلميح
    if (sq == hintFrom || sq == hintTo) {
      bg = Color.alphaBlend(const Color(0x9900BCD4), bg);
    }
    // مربع مختار
    if (sq == selected) {
      bg = Color.alphaBlend(theme.selected, bg);
    }
    // لون جودة النقلة (للمراجعة)
    final mc = moveColors[sq];
    if (mc != null) bg = Color.alphaBlend(_classColors[mc]!, bg);

    final isTarget = targets.contains(sq);
    final hasCapture = isTarget && p.isNotEmpty;

    return GestureDetector(
      onTap: onTap == null ? null : () => onTap!(sq),
      child: Container(
        color: bg,
        child: Stack(alignment: Alignment.center, children: [
          if (p.isNotEmpty)
            Positioned.fill(
              child: Padding(
                padding: const EdgeInsets.all(1),
                child: PieceWidget(p, settings: settings),
              ),
            ),
          // دائرة على الخانات الفارغة القانونية
          if (isTarget && !hasCapture)
            Container(
              width: 24, height: 24,
              decoration: const BoxDecoration(
                color: Color(0x55000000),
                shape: BoxShape.circle,
              ),
            ),
          // إطار دائري للأخذ
          if (hasCapture)
            Positioned.fill(
              child: Container(
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: const Color(0x88000000), width: 4),
                ),
              ),
            ),
          // ترقيم الملف/الرانك
          if (col == (flipped ? 7 : 0))
            Positioned(
              top: 1, right: 2,
              child: Text('$rank',
                  style: TextStyle(fontSize: 9,
                      color: (file + rank) % 2 == 1 ? theme.light : theme.dark)),
            ),
          if (row == (flipped ? 0 : 7))
            Positioned(
              bottom: 1, left: 2,
              child: Text(String.fromCharCode(97 + file),
                  style: TextStyle(fontSize: 9,
                      color: (file + rank) % 2 == 1 ? theme.light : theme.dark)),
            ),
        ]),
      ),
    );
  }
}
