import 'dart:async';
import 'package:stockfish/stockfish.dart';

/// نتيجة تحليل موضع واحد
class EvalResult {
  final int whiteCp;      // دايماً من جهة الأبيض
  final int? mateIn;      // موجب=الأبيض يمات، سالب=الأسود يمات
  final String bestMove;  // UCI e2e4
  final List<String> pv;  // أفضل تسلسل نقلات
  const EvalResult(this.whiteCp, this.mateIn, this.bestMove, this.pv);
  static const empty = EvalResult(0, null, '', []);
}

class Engine {
  Engine._();
  static final Engine instance = Engine._();

  Stockfish? _sf;
  Future<void>? _ready;
  Future<void> _queue = Future.value();
  Completer<void>? _done;

  bool _white = true;
  int _cp = 0;
  int? _mate;
  List<String> _pv = [];
  String _best = '';

  // آخر إعداد قوة (لتجنب إعادة الإرسال)
  String _lastCfg = '';

  Future<void> init() => _ready ??= _doInit();

  Future<void> _doInit() async {
    final sf = Stockfish();
    _sf = sf;
    while (sf.state.value != StockfishState.ready) {
      if (sf.state.value == StockfishState.error) throw Exception('Engine error');
      await Future.delayed(const Duration(milliseconds: 50));
    }
    sf.stdout.listen(_onOut);
    _send('uci');
    _send('setoption name Threads value 2');
    _send('setoption name Hash value 32');
    _send('isready');
  }

  void _send(String cmd) => _sf!.stdin = cmd;

  void _onOut(String chunk) {
    for (final line in chunk.split('\n')) {
      _parseLine(line.trim());
    }
  }

  void _parseLine(String line) {
    if (line.startsWith('info') &&
        line.contains(' score ') &&
        !line.contains('lowerbound') &&
        !line.contains('upperbound')) {
      final t = line.split(' ');
      final si = t.indexOf('score');
      final kind = t[si + 1];
      final val = int.tryParse(t[si + 2]) ?? 0;
      final sign = _white ? 1 : -1;
      if (kind == 'cp') {
        _cp = val * sign; _mate = null;
      } else if (kind == 'mate') {
        _mate = val * sign;
        _cp = (val > 0 ? 100000 - val * 100 : -100000 - val * 100) * sign;
      }
      final pi = t.indexOf('pv');
      if (pi != -1) _pv = t.sublist(pi + 1);
    } else if (line.startsWith('bestmove')) {
      final p = line.split(' ');
      _best = p.length > 1 ? p[1] : '';
      if (_done != null && !_done!.isCompleted) _done!.complete();
    }
  }

  void _configure(int? elo) {
    final key = 'elo:${elo ?? -1}';
    if (_lastCfg == key) return;
    _lastCfg = key;
    if (elo == null) {
      _send('setoption name UCI_LimitStrength value false');
      _send('setoption name Skill Level value 20');
    } else if (elo >= 1320) {
      _send('setoption name UCI_LimitStrength value true');
      _send('setoption name UCI_Elo value $elo');
    } else {
      _send('setoption name UCI_LimitStrength value false');
      final skill = ((elo - 400) / 92).round().clamp(0, 10);
      _send('setoption name Skill Level value $skill');
    }
  }

  Future<T> _enqueue<T>(Future<T> Function() job) {
    final c = Completer<T>();
    _queue = _queue.then((_) async {
      try { c.complete(await job()); }
      catch (e, st) { c.completeError(e, st); }
    });
    return c.future;
  }

  Future<EvalResult> _search(String fen, String go, int? elo) =>
      _enqueue<EvalResult>(() async {
        await init();
        _configure(elo);
        _white = fen.split(' ')[1] == 'w';
        _cp = 0; _mate = null; _pv = []; _best = '';
        _done = Completer<void>();
        _send('position fen $fen');
        _send(go);
        await _done!.future;
        return EvalResult(_cp, _mate, _best, List.of(_pv));
      });

  /// تحليل (بدون حد إيلو) — movetime بالمللي ثانية
  Future<EvalResult> analyze(String fen, {int movetime = 300}) =>
      _search(fen, 'go movetime $movetime', null);

  /// تحليل سريع للتلميح
  Future<EvalResult> hint(String fen) =>
      _search(fen, 'go movetime 500', null);

  /// نقلة البوت
  Future<String> botMove(String fen, int elo, {int movetime = 800}) async =>
      (await _search(fen, 'go movetime $movetime', elo)).bestMove;
}
