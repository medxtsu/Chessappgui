import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'pieces.dart';

// ───── ثيمات الرقعة ─────
class BoardTheme {
  final String name;
  final Color light, dark, highlight, selected;
  const BoardTheme(this.name, this.light, this.dark, this.highlight, this.selected);
}

const boardThemes = [
  BoardTheme('كلاسيك', Color(0xFFEEEED2), Color(0xFF769656), Color(0xAAF6F669), Color(0xAFF6F624)),
  BoardTheme('بحري',   Color(0xFFDEE3E6), Color(0xFF4B7399), Color(0xAAF6F669), Color(0xAFF6F624)),
  BoardTheme('رمادي',  Color(0xFFD0D0D0), Color(0xFF707070), Color(0xAAF6F669), Color(0xAFF6F624)),
  BoardTheme('رملي',   Color(0xFFF0D9B5), Color(0xFFB58863), Color(0xAAF6F669), Color(0xAFF6F624)),
  BoardTheme('ليلي',   Color(0xFF3C3C3C), Color(0xFF1A1A1A), Color(0xAAF6F669), Color(0xAFF6F624)),
];

// ───── مجموعة القطع ─────
class PieceSet {
  final String id, name;
  final Map<String, String> paths;
  const PieceSet(this.id, this.name, this.paths);
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'paths': paths};
  factory PieceSet.fromJson(Map<String, dynamic> j) =>
      PieceSet(j['id'], j['name'], Map<String, String>.from(j['paths']));
}

// ───── الإعدادات الكاملة ─────
class AppSettings {
  int boardThemeIdx;
  String pieceSetId;
  List<PieceSet> customSets;
  String botName, botAvatar;
  int botElo;
  bool timerEnabled, timerIncrement;
  int timerSeconds, timerIncrementSec;

  AppSettings({
    this.boardThemeIdx = 0, this.pieceSetId = 'default',
    this.customSets = const [],
    this.botName = 'بوت', this.botAvatar = 'emoji:🤖', this.botElo = 1500,
    this.timerEnabled = false, this.timerSeconds = 300,
    this.timerIncrement = false, this.timerIncrementSec = 2,
  });

  BoardTheme get boardTheme => boardThemes[boardThemeIdx.clamp(0, boardThemes.length - 1)];

  PieceSet? get activePieceSet {
    if (pieceSetId == 'default') return null;
    for (final s in customSets) if (s.id == pieceSetId) return s;
    return null;
  }

  static Future<AppSettings> load() async {
    final p = await SharedPreferences.getInstance();
    final s = AppSettings(
      boardThemeIdx: p.getInt('boardThemeIdx') ?? 0,
      pieceSetId: p.getString('pieceSetId') ?? 'default',
      botName: p.getString('botName') ?? 'بوت',
      botElo: p.getInt('botElo') ?? 1500,
      botAvatar: p.getString('botAvatar') ?? 'emoji:🤖',
      timerEnabled: p.getBool('timerEnabled') ?? false,
      timerSeconds: p.getInt('timerSeconds') ?? 300,
      timerIncrement: p.getBool('timerIncrement') ?? false,
      timerIncrementSec: p.getInt('timerIncrementSec') ?? 2,
    );
    final raw = p.getString('customSets');
    if (raw != null) {
      final list = jsonDecode(raw) as List;
      s.customSets = list.map((e) => PieceSet.fromJson(e)).toList();
    }
    return s;
  }

  Future<void> save() async {
    final p = await SharedPreferences.getInstance();
    await p.setInt('boardThemeIdx', boardThemeIdx);
    await p.setString('pieceSetId', pieceSetId);
    await p.setString('botName', botName);
    await p.setInt('botElo', botElo);
    await p.setString('botAvatar', botAvatar);
    await p.setBool('timerEnabled', timerEnabled);
    await p.setInt('timerSeconds', timerSeconds);
    await p.setBool('timerIncrement', timerIncrement);
    await p.setInt('timerIncrementSec', timerIncrementSec);
    await p.setString('customSets', jsonEncode(customSets.map((s) => s.toJson()).toList()));
  }

  static Future<PieceSet?> importPieceSet(String name) async {
    final picker = ImagePicker();
    final keys = ['wK','wQ','wR','wB','wN','wP','bK','bQ','bR','bB','bN','bP'];
    final dir = await getApplicationDocumentsDirectory();
    final id = DateTime.now().millisecondsSinceEpoch.toString();
    final setDir = Directory('${dir.path}/pieces/$id');
    await setDir.create(recursive: true);
    final paths = <String, String>{};
    for (final key in keys) {
      final x = await picker.pickImage(source: ImageSource.gallery, maxWidth: 256, imageQuality: 90);
      if (x == null) return null;
      final ext = x.path.substring(x.path.lastIndexOf('.'));
      final dest = '${setDir.path}/$key$ext';
      await File(x.path).copy(dest);
      paths[key] = dest;
    }
    return PieceSet(id, name, paths);
  }

  Future<void> deletePieceSet(String id) async {
    final dir = await getApplicationDocumentsDirectory();
    final d = Directory('${dir.path}/pieces/$id');
    if (await d.exists()) await d.delete(recursive: true);
    customSets.removeWhere((s) => s.id == id);
    if (pieceSetId == id) pieceSetId = 'default';
    await save();
  }
}

// ───── Widget قطعة واحدة ─────
class PieceWidget extends StatelessWidget {
  final String piece;
  final double size;
  final AppSettings settings;
  const PieceWidget(this.piece, {super.key, this.size = 48, required this.settings});

  String get _key => '${piece == piece.toUpperCase() ? 'w' : 'b'}${piece.toUpperCase()}';

  @override
  Widget build(BuildContext context) {
    final set = settings.activePieceSet;
    if (set != null) {
      final path = set.paths[_key];
      if (path != null && File(path).existsSync()) {
        return SizedBox(width: size, height: size,
            child: Image.file(File(path), fit: BoxFit.contain));
      }
    }
    return SizedBox(width: size, height: size,
        child: CustomPaint(painter: PiecePainter(piece)));
  }
}

// ───── Avatar helper ─────
class AvatarWidget extends StatelessWidget {
  final String avatar;
  final double radius;
  const AvatarWidget(this.avatar, {super.key, this.radius = 24});
  @override
  Widget build(BuildContext context) {
    if (avatar.startsWith('emoji:')) {
      return CircleAvatar(radius: radius,
          child: Text(avatar.substring(6), style: TextStyle(fontSize: radius * 0.9)));
    }
    return CircleAvatar(radius: radius,
        backgroundImage: FileImage(File(avatar)));
  }
}
