import 'dart:async';
import 'package:stockfish/stockfish.dart';

/// نتيجة تحليل موضع. التقييم دائماً من جهة الأبيض.
class EvalResult {
  final int whiteCp; // سنتي بيدق (المات يتحول لرقم كبير)
  final int? mateIn; // موجب = الأبيض يمات، سالب = الأسود يمات
  final String bestMove; // UCI مثل e2e4
  final List<String> pv;
  const EvalResult(this.whiteCp, this.mateIn, this.bestMove, this.pv);
}

class Engine {
  Engine._();
  static final Engine instance = Engine._();

  Stockfish? _sf;
  Future<void>? _initFuture;
  Future<void> _queue = Future.value();
  Completer<void>? _done;
  bool _whiteToMove = true;
  int _cp = 0;
  int? _mate;
  List<String> _pv = [];
  String _best = '';
  int _cfg = -2; // آخر إعداد قوة تم تطبيقه (-1 = قوة كاملة)

  Future<void> init() => _initFuture ??= _init();

  Future<void> _init() async {
    final sf = Stockfish();
    _sf = sf;
    while (sf.state.value != StockfishState.ready) {
      if (sf.state.value == StockfishState.error) {
        throw Exception('Stockfish failed to start');
      }
      await Future.delayed(const Duration(milliseconds: 50));
    }
    sf.stdout.listen(_onOutput);
    _send('uci');
    // إعدادات خفيفة لجهاز مثل Infinix Hot 30i
    _send('setoption name Threads value 2');
    _send('setoption name Hash value 32');
    _send('isready');
  }

  void _send(String cmd) => _sf!.stdin = cmd;

  void _onOutput(String chunk) {
    for (final line in chunk.split('\n')) {
      _onLine(line.trim());
    }
  }

  void _onLine(String line) {
    if (line.startsWith('info') &&
        line.contains(' score ') &&
        !line.contains('lowerbound') &&
        !line.contains('upperbound')) {
      final t = line.split(' ');
      final si = t.indexOf('score');
      final kind = t[si + 1];
      final val = int.tryParse(t[si + 2]) ?? 0;
      final sign = _whiteToMove ? 1 : -1;
      if (kind == 'cp') {
        _cp = val * sign;
        _mate = null;
      } else if (kind == 'mate') {
        _mate = val * sign;
        final big = val > 0 ? 100000 - val * 100 : -100000 - val * 100;
        _cp = big * sign;
      }
      final pi = t.indexOf('pv');
      if (pi != -1) _pv = t.sublist(pi + 1);
    } else if (line.startsWith('bestmove')) {
      final parts = line.split(' ');
      _best = parts.length > 1 ? parts[1] : '';
      if (_done != null && !_done!.isCompleted) _done!.complete();
    }
  }

  /// elo == null يعني قوة كاملة (للتحليل).
  void _configure(int? elo) {
    final key = elo ?? -1;
    if (_cfg == key) return;
    _cfg = key;
    if (elo == null) {
      _send('setoption name UCI_LimitStrength value false');
      _send('setoption name Skill Level value 20');
    } else if (elo >= 1320) {
      _send('setoption name Skill Level value 20');
      _send('setoption name UCI_LimitStrength value true');
      _send('setoption name UCI_Elo value $elo');
    } else {
      // Stockfish لا يدعم Elo أقل من 1320 رسمياً، فنستخدم Skill Level (تقريبي)
      _send('setoption name UCI_LimitStrength value false');
      final skill = ((elo - 400) / 92).round().clamp(0, 10);
      _send('setoption name Skill Level value $skill');
    }
  }

  Future<T> _enqueue<T>(Future<T> Function() job) {
    final c = Completer<T>();
    _queue = _queue.then((_) async {
      try {
        c.complete(await job());
      } catch (e, st) {
        c.completeError(e, st);
      }
    });
    return c.future;
  }

  Future<EvalResult> _search(String fen, String go, int? elo) =>
      _enqueue<EvalResult>(() async {
        await init();
        _configure(elo);
        _whiteToMove = fen.split(' ')[1] == 'w';
        _cp = 0;
        _mate = null;
        _pv = [];
        _best = '';
        _done = Completer<void>();
        _send('position fen $fen');
        _send(go);
        await _done!.future;
        return EvalResult(_cp, _mate, _best, List.of(_pv));
      });

  /// تحليل بقوة كاملة (للمراجعة).
  Future<EvalResult> analyze(String fen, {int movetime = 300}) =>
      _search(fen, 'go movetime $movetime', null);

  /// نقلة البوت بالإيلو المطلوب.
  Future<String> botMove(String fen, int elo, {int movetime = 600}) async =>
      (await _search(fen, 'go movetime $movetime', elo)).bestMove;
}
