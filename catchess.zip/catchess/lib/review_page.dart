import 'package:flutter/material.dart';
import 'chess_utils.dart';
import 'engine.dart';
import 'explainer.dart';
import 'settings.dart';
import 'board_view.dart';

class ReviewPage extends StatefulWidget {
  final List<Ply> plies;
  final bool userWhite;
  final AppSettings settings;
  const ReviewPage({
    super.key,
    required this.plies,
    required this.userWhite,
    required this.settings,
  });
  @override State<ReviewPage> createState() => _ReviewPageState();
}

class _ReviewPageState extends State<ReviewPage> {
  List<MoveReview>? _reviews;
  bool _analyzing = false;
  int _done = 0;
  int _idx = -1;              // -1 = موضع البداية
  bool _showBestLine = false;
  int _bestLineIdx = 0;       // موضع داخل التسلسل الأفضل

  List<Ply> get _plies => widget.plies;

  Future<void> _analyze() async {
    setState(() { _analyzing = true; _done = 0; });
    final fens = [_plies.first.fenBefore, ..._plies.map((p) => p.fenAfter)];
    final evals = <EvalResult>[];
    for (final f in fens) {
      evals.add(await Engine.instance.analyze(f, movetime: 400));
      if (!mounted) return;
      setState(() => _done = evals.length);
    }
    final rv = [
      for (var i = 0; i < _plies.length; i++)
        reviewMove(i, _plies[i], evals[i], evals[i + 1]),
    ];
    setState(() { _reviews = rv; _analyzing = false; _idx = rv.length - 1; });
  }

  void _go(int i) => setState(() {
    _idx = i.clamp(-1, _plies.length - 1);
    _showBestLine = false;
    _bestLineIdx = 0;
  });

  Color _cls2color(MoveClass c) => switch (c) {
    MoveClass.best => Colors.green.shade600,
    MoveClass.excellent => Colors.green.shade400,
    MoveClass.good => Colors.lightGreen.shade600,
    MoveClass.book => Colors.brown.shade400,
    MoveClass.inaccuracy => Colors.amber.shade700,
    MoveClass.mistake => Colors.orange.shade700,
    MoveClass.missedWin => Colors.red.shade600,
    MoveClass.blunder => Colors.red.shade900,
  };

  String _cls2icon(MoveClass c) => classEmoji[c] ?? '?';

  // ─── بناء خريطة ألوان من/إلى للموضع الحالي ───
  Map<String, MoveClass> _buildMoveColors() {
    final rv = _reviews;
    if (rv == null || _idx < 0) return {};
    final r = rv[_idx];
    return {
      _plies[_idx].uci.substring(0, 2): r.cls,
      _plies[_idx].uci.substring(2, 4): r.cls,
    };
  }

  // ─── FEN للعرض الحالي ───
  String get _displayFen {
    if (_showBestLine && _idx >= 0) {
      final rv = _reviews![_idx];
      String f = _plies[_idx].fenBefore;
      for (var i = 0; i <= _bestLineIdx && i < rv.bestLine.length; i++) {
        f = applyUci(f, rv.bestLine[i]) ?? f;
      }
      return f;
    }
    return _idx < 0 ? _plies.first.fenBefore : _plies[_idx].fenAfter;
  }

  @override
  Widget build(BuildContext context) {
    if (_plies.isEmpty) {
      return const Center(child: Text('العب مباراة أولاً ثم ارجع للمراجعة.'));
    }
    final rv = _reviews;
    if (rv == null) {
      return Center(child: Padding(padding: const EdgeInsets.all(24), child:
        Column(mainAxisSize: MainAxisSize.min, children: [
          Text('${_plies.length} نقلة جاهزة.'),
          const SizedBox(height: 14),
          if (_analyzing) ...[
            LinearProgressIndicator(value: _done / (_plies.length + 1)),
            const SizedBox(height: 8),
            Text('$_done / ${_plies.length + 1}'),
          ] else
            FilledButton(onPressed: _analyze, child: const Text('حلّل المباراة')),
        ]),
      ));
    }

    final r = _idx >= 0 ? rv[_idx] : null;
    final lastUci = _idx < 0 ? null : _plies[_idx].uci;

    return ListView(padding: const EdgeInsets.all(10), children: [
      // ─── الرقعة ───
      BoardView(
        fen: _displayFen,
        settings: widget.settings,
        flipped: !widget.userWhite,
        lastFrom: lastUci?.substring(0, 2),
        lastTo:   lastUci?.substring(2, 4),
        moveColors: _showBestLine ? {} : _buildMoveColors(),
      ),

      // ─── تنقل ───
      Directionality(
        textDirection: TextDirection.ltr,
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          IconButton(icon: const Icon(Icons.first_page), onPressed: () => _go(-1)),
          IconButton(icon: const Icon(Icons.chevron_left), onPressed: () => _go(_idx - 1)),
          Text('${_idx + 1} / ${_plies.length}', style: const TextStyle(fontSize: 16)),
          IconButton(icon: const Icon(Icons.chevron_right), onPressed: () => _go(_idx + 1)),
          IconButton(icon: const Icon(Icons.last_page), onPressed: () => _go(_plies.length - 1)),
        ]),
      ),

      // ─── شرح النقلة ───
      if (r != null)
        Card(margin: const EdgeInsets.symmetric(vertical: 6),
          child: Padding(padding: const EdgeInsets.all(12), child:
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Container(width: 12, height: 12,
                    decoration: BoxDecoration(color: _cls2color(r.cls), shape: BoxShape.circle)),
                const SizedBox(width: 8),
                Text('${r.san}  ${_cls2icon(r.cls)}  ${classLabel[r.cls]}',
                    style: Theme.of(context).textTheme.titleMedium),
              ]),
              const SizedBox(height: 6),
              Text(r.text),
              // زر عرض التسلسل الأفضل
              if (r.bestLine.isNotEmpty) ...[
                const SizedBox(height: 8),
                TextButton.icon(
                  icon: Icon(_showBestLine ? Icons.visibility_off : Icons.visibility),
                  label: Text(_showBestLine ? 'إخفاء التسلسل الأفضل' : 'عرض التسلسل الأفضل'),
                  onPressed: () => setState(() {
                    _showBestLine = !_showBestLine;
                    _bestLineIdx = 0;
                  }),
                ),
                if (_showBestLine)
                  Directionality(
                    textDirection: TextDirection.ltr,
                    child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      IconButton(icon: const Icon(Icons.arrow_back),
                          onPressed: _bestLineIdx > 0
                              ? () => setState(() => _bestLineIdx--)
                              : null),
                      Text('${_bestLineIdx + 1} / ${r.bestLine.length}'),
                      IconButton(icon: const Icon(Icons.arrow_forward),
                          onPressed: _bestLineIdx < r.bestLine.length - 1
                              ? () => setState(() => _bestLineIdx++)
                              : null),
                    ]),
                  ),
              ],
            ]),
          ),
        ),

      // ─── إحصائيات ───
      Card(margin: const EdgeInsets.symmetric(vertical: 4),
        child: Padding(padding: const EdgeInsets.all(10), child:
          Row(children: [
            Expanded(child: _StatsColumn(rv: rv, white: true,  label: 'الأبيض')),
            const VerticalDivider(width: 1),
            Expanded(child: _StatsColumn(rv: rv, white: false, label: 'الأسود')),
          ]),
        ),
      ),

      // ─── تسلسل النقلات الملونة ───
      const SizedBox(height: 8),
      Wrap(spacing: 4, runSpacing: 4, children: [
        for (var i = 0; i < rv.length; i++)
          ActionChip(
            avatar: Text(_cls2icon(rv[i].cls), style: const TextStyle(fontSize: 11)),
            label: Text(
              '${i ~/ 2 + 1}${i.isEven ? '.' : '…'} ${rv[i].san}',
              style: const TextStyle(color: Colors.white, fontSize: 11),
            ),
            backgroundColor: _cls2color(rv[i].cls),
            side: i == _idx
                ? const BorderSide(color: Colors.white, width: 2)
                : BorderSide.none,
            onPressed: () => _go(i),
          ),
      ]),
    ]);
  }
}

class _StatsColumn extends StatelessWidget {
  final List<MoveReview> rv;
  final bool white;
  final String label;
  const _StatsColumn({required this.rv, required this.white, required this.label});

  @override
  Widget build(BuildContext context) {
    final counts = classCount(rv, white);
    final acc = accuracy(rv, white);
    return Column(children: [
      Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
      Text('دقة ${acc.round()}%', style: TextStyle(
          color: acc >= 80 ? Colors.green : acc >= 60 ? Colors.orange : Colors.red,
          fontWeight: FontWeight.bold)),
      for (final c in MoveClass.values)
        if ((counts[c] ?? 0) > 0)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 1),
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Text(classEmoji[c]!, style: const TextStyle(fontSize: 12)),
              const SizedBox(width: 4),
              Text('${classLabel[c]}: ${counts[c]}',
                  style: const TextStyle(fontSize: 12)),
            ]),
          ),
    ]);
  }
}
