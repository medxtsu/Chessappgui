import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'engine.dart';
import 'settings.dart';
import 'play_page.dart';
import 'review_page.dart';
import 'settings_page.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(const CatchessApp());
}

class CatchessApp extends StatelessWidget {
  const CatchessApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Catchess',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      colorSchemeSeed: Colors.teal,
      brightness: Brightness.dark,
    ),
    builder: (c, w) => Directionality(textDirection: TextDirection.rtl, child: w!),
    home: const _Root(),
  );
}

class _Root extends StatefulWidget {
  const _Root();
  @override State<_Root> createState() => _RootState();
}

class _RootState extends State<_Root> {
  AppSettings? _s;
  late final Future<void> _engineReady;
  List<Ply> _lastGame = [];
  bool _userWhite = true;
  int _tab = 0;

  @override
  void initState() {
    super.initState();
    _engineReady = Engine.instance.init();
    AppSettings.load().then((s) => setState(() => _s = s));
  }

  void _onGameEnd(List<Ply> plies, bool white) {
    setState(() { _lastGame = plies; _userWhite = white; });
  }

  @override
  Widget build(BuildContext context) {
    final s = _s;
    if (s == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: _tab, children: [
        PlayPage(
          key: const ValueKey('play'),
          settings: s,
          engineReady: _engineReady,
          onGameEnd: _onGameEnd,
          onReview: () => setState(() => _tab = 1),
        ),
        ReviewPage(
          key: ObjectKey(_lastGame),
          plies: _lastGame,
          userWhite: _userWhite,
          settings: s,
        ),
        SettingsPage(
          settings: s,
          onChanged: () => setState(() {}),
        ),
      ])),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.sports_esports_outlined), selectedIcon: Icon(Icons.sports_esports), label: 'لعب'),
          NavigationDestination(icon: Icon(Icons.bar_chart_outlined), selectedIcon: Icon(Icons.bar_chart), label: 'مراجعة'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'إعدادات'),
        ],
      ),
    );
  }
}
