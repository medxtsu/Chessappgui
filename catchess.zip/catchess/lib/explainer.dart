import 'dart:math';
import 'chess_utils.dart';
import 'engine.dart';

enum MoveClass { best, excellent, good, book, inaccuracy, mistake, missedWin, blunder }

const classLabel = {
  MoveClass.best: 'الأفضل',
  MoveClass.excellent: 'ممتازة',
  MoveClass.good: 'جيدة',
  MoveClass.book: 'كتاب',
  MoveClass.inaccuracy: 'غير دقيقة',
  MoveClass.mistake: 'خطأ',
  MoveClass.missedWin: 'أضاعت فرصة',
  MoveClass.blunder: 'خطأ فادح',
};

const classEmoji = {
  MoveClass.best: '!!',
  MoveClass.excellent: '!',
  MoveClass.good: '★',
  MoveClass.book: '📖',
  MoveClass.inaccuracy: '?!',
  MoveClass.mistake: '?',
  MoveClass.missedWin: '✗',
  MoveClass.blunder: '??',
};

const _pieceAr = {
  'p': 'بيدق', 'n': 'حصان', 'b': 'فيل', 'r': 'قلعة', 'q': 'وزير', 'k': 'ملك',
};

class MoveReview {
  final int idx;
  final bool white;
  final String san, uci;
  final String? bestSan;
  final MoveClass cls;
  final double winLoss; // نقاط فقدان الاحتمال (0–100)
  final String text;
  final List<String> bestLine; // تسلسل النقلات الأفضل (UCI)
  const MoveReview(this.idx, this.white, this.san, this.uci, this.bestSan,
      this.cls, this.winLoss, this.text, this.bestLine);
}

double winPct(int cp) {
  final c = cp.clamp(-1500, 1500).toDouble();
  return 50 + 50 * (2 / (1 + exp(-0.00368208 * c)) - 1);
}

MoveClass _classify(double loss, bool isBest, bool hadMate, bool lostMate) {
  if (lostMate) return MoveClass.missedWin;
  if (isBest || loss < 2) return MoveClass.best;
  if (loss < 5) return MoveClass.excellent;
  if (loss < 10) return MoveClass.good;
  if (loss < 20) return MoveClass.inaccuracy;
  if (loss < 35) return MoveClass.mistake;
  return MoveClass.blunder;
}

String _evalStr(int cp) {
  if (cp.abs() >= 90000) return cp > 0 ? 'مات للأبيض' : 'مات للأسود';
  return '${cp >= 0 ? '+' : ''}${(cp / 100).toStringAsFixed(1)}';
}

MoveReview reviewMove(int i, Ply p, EvalResult before, EvalResult after) {
  final white = p.fenBefore.split(' ')[1] == 'w';
  final sign = white ? 1 : -1;
  final myBefore = before.whiteCp * sign;
  final myAfter = after.whiteCp * sign;
  final loss = max(0.0, winPct(myBefore) - winPct(myAfter));
  final isBest = p.uci == before.bestMove;

  // هل كان هناك مات متاح وضيّعه؟
  final hadMate = before.mateIn != null && before.mateIn! * sign > 0;
  final keptMate = after.mateIn != null && after.mateIn! * sign > 0;
  final lostMate = hadMate && !keptMate && !isBest;

  final cls = _classify(loss, isBest, hadMate, lostMate);
  final bestSan = isBest ? null : sanFor(p.fenBefore, before.bestMove);
  final text = _buildText(p, before, after, sign, cls, bestSan, lostMate);

  return MoveReview(i, white, p.san, p.uci, bestSan, cls, loss, text, before.pv);
}

String _buildText(Ply p, EvalResult before, EvalResult after, int sign,
    MoveClass cls, String? bestSan, bool lostMate) {
  final parts = <String>[];
  final board = parseBoard(p.fenBefore);
  final from = p.uci.substring(0, 2);
  final to = p.uci.substring(2, 4);
  final mover = pieceAt(board, from)?.toLowerCase() ?? 'p';
  final victim = pieceAt(board, to)?.toLowerCase();

  // وصف النقلة
  if (p.san.startsWith('O-O')) {
    parts.add('تحصين: أمّنت ملكك وأدخلت القلعة في اللعب.');
  } else if (p.san.contains('=')) {
    parts.add('ترقية بيدق — مكسب مادي كبير.');
  } else if (victim != null) {
    parts.add('أخذت ${_pieceAr[victim]} بـ${_pieceAr[mover]}.');
  } else {
    parts.add('حرّكت ${_pieceAr[mover]} إلى $to.');
  }

  if (p.san.endsWith('#')) {
    parts.add('كش مات! 🎉');
    return parts.join('\n');
  }
  if (p.san.endsWith('+')) parts.add('النقلة تعطي كش.');

  // مات متاح؟
  final m = after.mateIn;
  if (m != null) {
    final mine = m * sign;
    if (mine > 0) parts.add('عندك مات خلال ${mine.abs()} نقلة 🔥');
    else if (mine < 0) parts.add('تنبيه: الخصم يمات خلال ${mine.abs()} نقلة!');
  }

  // جودة النقلة
  switch (cls) {
    case MoveClass.best:
      parts.add('نفس اختيار المحرك ✓');
    case MoveClass.excellent || MoveClass.good:
      parts.add('نقلة ${classLabel[cls]} وقريبة من الأفضل.');
    case MoveClass.missedWin:
      parts.add('كان عندك مات أو مكسب حاسم وما استغللته!');
      if (bestSan != null) parts.add('الأفضل كان $bestSan.');
    default:
      final bef = _evalStr(before.whiteCp * sign);
      final aft = _evalStr(after.whiteCp * sign);
      parts.add('التقييم تغيّر من $bef إلى $aft.');
      if (bestSan != null) parts.add('الأفضل كان $bestSan.');
      // رد الخصم المتوقع
      if (after.pv.isNotEmpty) {
        final reply = after.pv.first;
        if (reply.length >= 4) {
          final rsan = sanFor(p.fenAfter, reply);
          if (rsan != null) parts.add('الخصم يستغل بـ $rsan.');
        }
      }
  }

  parts.add('التقييم: ${_evalStr(after.whiteCp)}');
  return parts.join('\n');
}

double accuracy(List<MoveReview> all, bool white) {
  final mine = all.where((r) => r.white == white).toList();
  if (mine.isEmpty) return 100;
  var sum = 0.0;
  for (final r in mine) {
    sum += (103.1668 * exp(-0.04354 * r.winLoss) - 3.1669).clamp(0, 100);
  }
  return sum / mine.length;
}

Map<MoveClass, int> classCount(List<MoveReview> all, bool white) {
  final m = <MoveClass, int>{};
  for (final c in MoveClass.values) m[c] = 0;
  for (final r in all.where((r) => r.white == white)) {
    m[r.cls] = (m[r.cls] ?? 0) + 1;
  }
  return m;
}
