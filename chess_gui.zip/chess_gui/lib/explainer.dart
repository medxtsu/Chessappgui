import 'dart:math';
import 'chess_utils.dart';
import 'engine.dart';

/// "الذكاء الاصطناعي الخفيف": قواعد تقرأ نتائج Stockfish وتكتب شرح بالعربي.
/// صفر استهلاك رام تقريباً، وفوري.

enum MoveClass { best, excellent, good, inaccuracy, mistake, blunder }

String classLabel(MoveClass c) => switch (c) {
      MoveClass.best => 'الأفضل',
      MoveClass.excellent => 'ممتازة',
      MoveClass.good => 'جيدة',
      MoveClass.inaccuracy => 'غير دقيقة',
      MoveClass.mistake => 'خطأ',
      MoveClass.blunder => 'غلطة فادحة',
    };

const pieceAr = {
  'p': 'البيدق',
  'n': 'الحصان',
  'b': 'الفيل',
  'r': 'القلعة',
  'q': 'الوزير',
  'k': 'الملك',
};

class MoveReview {
  final int ply;
  final bool white;
  final String san;
  final String? bestSan;
  final MoveClass cls;
  final double winLoss;
  final String text;
  const MoveReview(this.ply, this.white, this.san, this.bestSan, this.cls,
      this.winLoss, this.text);
}

/// احتمال الفوز % من التقييم (نفس معادلة Lichess).
double winPct(int cp) {
  final c = cp.clamp(-1000, 1000);
  return 50 + 50 * (2 / (1 + exp(-0.00368208 * c)) - 1);
}

MoveClass classify(double loss, bool isBest) {
  if (isBest || loss < 2) return MoveClass.best;
  if (loss < 5) return MoveClass.excellent;
  if (loss < 10) return MoveClass.good;
  if (loss < 20) return MoveClass.inaccuracy;
  if (loss < 30) return MoveClass.mistake;
  return MoveClass.blunder;
}

double accuracy(List<MoveReview> all, bool white) {
  final mine = all.where((r) => r.white == white).toList();
  if (mine.isEmpty) return 100;
  var sum = 0.0;
  for (final r in mine) {
    sum += (103.1668 * exp(-0.04354 * r.winLoss) - 3.1669).clamp(0, 100);
  }
  return sum / mine.length;
}

String evalStr(int cp,
    {String win = 'مات للأبيض', String lose = 'مات للأسود'}) {
  if (cp.abs() >= 90000) return cp > 0 ? win : lose;
  return '${cp >= 0 ? '+' : ''}${(cp / 100).toStringAsFixed(1)}';
}

MoveReview reviewMove(int i, Ply p, EvalResult before, EvalResult after) {
  final white = p.fenBefore.split(' ')[1] == 'w';
  final sign = white ? 1 : -1;
  final loss = max(
      0.0, winPct(before.whiteCp * sign) - winPct(after.whiteCp * sign));
  final isBest = p.uci == before.bestMove;
  final cls = classify(loss, isBest);
  final bestSan = isBest ? null : sanFor(p.fenBefore, before.bestMove);
  return MoveReview(
      i, white, p.san, bestSan, cls, loss, _explain(p, before, after, sign, cls, bestSan));
}

String _explain(Ply p, EvalResult before, EvalResult after, int sign,
    MoveClass cls, String? bestSan) {
  final out = <String>[];
  final board = parseBoard(p.fenBefore);
  final from = p.uci.substring(0, 2);
  final to = p.uci.substring(2, 4);
  final mover = pieceAt(board, from)!.toLowerCase();
  final victim = pieceAt(board, to)?.toLowerCase();
  final san = p.san;

  // 1) وش سوت النقلة
  if (san.startsWith('O-O')) {
    out.add('تحصين: ملكك صار أأمن وقلعتك دخلت اللعب.');
  } else if (san.contains('=')) {
    out.add('ترقية البيدق — مكسب مادي كبير.');
  } else if (victim != null) {
    out.add('أخذت ${pieceAr[victim]} بواسطة ${pieceAr[mover]}.');
  } else {
    out.add('حرّكت ${pieceAr[mover]} إلى $to.');
  }
  if (san.endsWith('#')) {
    out.add('كش مات! 🎉');
  } else if (san.endsWith('+')) {
    out.add('والنقلة تعطي كش.');
  }

  // 2) المات
  final m = after.mateIn;
  if (m != null) {
    final mine = m * sign;
    if (mine > 0) {
      out.add('عندك مات خلال ${mine.abs()} نقلات 🔥');
    } else if (mine < 0) {
      out.add('تنبيه: بعد هالنقلة الخصم يقدر يمات خلال ${mine.abs()} نقلات.');
    }
  }

  // 3) تقييم الجودة
  if (cls == MoveClass.best) {
    out.add('نقلة دقيقة — نفس اختيار المحرك.');
  } else if (cls == MoveClass.excellent || cls == MoveClass.good) {
    out.add('نقلة ${classLabel(cls)} وقريبة من الأفضل.');
  } else {
    out.add(
        'التقييم نزل من ${evalStr(before.whiteCp * sign, win: 'مات لصالحك', lose: 'مات ضدك')} إلى ${evalStr(after.whiteCp * sign, win: 'مات لصالحك', lose: 'مات ضدك')}.');
    if (bestSan != null) {
      final bv = pieceAt(board, before.bestMove.substring(2, 4))?.toLowerCase();
      var why = 'الأفضل كان $bestSan';
      if (bestSan.endsWith('#')) {
        why += ' وهي كش مات!';
      } else if (bv != null) {
        why += ' وتأخذ ${pieceAr[bv]}';
      } else if (bestSan.endsWith('+')) {
        why += ' وتعطي كش مع الحفاظ على المبادرة';
      }
      out.add('$why.');
    }
    // رد الخصم المتوقع
    final reply = after.pv.isNotEmpty ? after.pv.first : null;
    if (reply != null && reply.length >= 4 && !statusOf(p.fenAfter).over) {
      final rv = pieceAt(parseBoard(p.fenAfter), reply.substring(2, 4))
          ?.toLowerCase();
      final rsan = sanFor(p.fenAfter, reply);
      if (rv != null && rsan != null) {
        out.add('الخصم يستغلها بـ $rsan ويأخذ ${pieceAr[rv]}.');
      }
    }
  }

  // 4) الوضع العام
  final cp = after.whiteCp;
  final a = cp.abs();
  final level = a < 30
      ? 'الوضع متوازن'
      : a < 100
          ? 'أفضلية طفيفة'
          : a < 300
              ? 'أفضلية واضحة'
              : 'أفضلية حاسمة';
  final side = a < 30 ? '' : (cp > 0 ? ' للأبيض' : ' للأسود');
  out.add('التقييم الحالي: ${evalStr(cp)} ($level$side).');

  return out.join('\n');
}
