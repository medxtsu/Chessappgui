import 'package:chess/chess.dart' as cl;

const startFen = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';

class Ply {
  final String fenBefore, fenAfter, uci, san;
  const Ply(this.fenBefore, this.fenAfter, this.uci, this.san);
}

class GameStatus {
  final bool over, mate, draw;
  const GameStatus({this.over = false, this.mate = false, this.draw = false});
}

/// FEN → 8×8 matrix, row 0 = rank 8. empty cell = ''
List<List<String>> parseBoard(String fen) {
  final rows = fen.split(' ')[0].split('/');
  return rows.map((row) {
    final r = <String>[];
    for (final c in row.split('')) {
      final n = int.tryParse(c);
      if (n != null) r.addAll(List.filled(n, ''));
      else r.add(c);
    }
    return r;
  }).toList();
}

String? pieceAt(List<List<String>> board, String sq) {
  final file = sq.codeUnitAt(0) - 97;
  final rank = int.parse(sq[1]);
  final p = board[8 - rank][file];
  return p.isEmpty ? null : p;
}

/// Apply UCI move; returns new FEN or null if illegal
String? applyUci(String fen, String uci) {
  final g = cl.Chess.fromFEN(fen);
  final move = <String, String>{
    'from': uci.substring(0, 2),
    'to': uci.substring(2, 4),
  };
  if (uci.length > 4) move['promotion'] = uci.substring(4, 5);
  return g.move(move) ? g.fen : null;
}

/// UCI → SAN for a position
String? sanFor(String fen, String uci) {
  if (uci.length < 4) return null;
  final target = applyUci(fen, uci);
  if (target == null) return null;
  for (final s in cl.Chess.fromFEN(fen).moves()) {
    final g = cl.Chess.fromFEN(fen);
    if (g.move(s) && g.fen == target) return s.toString();
  }
  return null;
}

/// All legal target squares for piece on [from]
List<String> legalTargets(String fen, String from) {
  final out = <String>[];
  for (final f in 'abcdefgh'.split('')) {
    for (var r = 1; r <= 8; r++) {
      final to = '$f$r';
      if (to == from) continue;
      final g = cl.Chess.fromFEN(fen);
      if (g.move({'from': from, 'to': to, 'promotion': 'q'})) out.add(to);
    }
  }
  return out;
}

GameStatus statusOf(String fen) {
  final g = cl.Chess.fromFEN(fen);
  if (!g.game_over) return const GameStatus();
  return GameStatus(
    over: true,
    mate: g.in_checkmate,
    draw: g.in_draw || g.in_stalemate || g.insufficient_material,
  );
}

/// Does the current side have promotion candidates?
bool needsPromo(String fen, String from, String to) {
  final board = parseBoard(fen);
  final p = pieceAt(board, from);
  if (p == null) return false;
  return p.toLowerCase() == 'p' && (to.endsWith('8') || to.endsWith('1'));
}
